<!-- bootstrap Scripts-->
<script src="<?=base_url();?>/assets/bootstrap-3.2.0/js/bootstrap.min.js"></script>

<!-- Data table Scripts-->
<script src="<?=base_url();?>/assets/datatable/js/jquery.dataTables.js"></script>
<script src="<?=base_url();?>/assets/datatable/js/dataTables.bootstrap.js"></script>
<script type="text/javascript">
    $(function() {
        $("#example1").dataTable();
    });
</script>