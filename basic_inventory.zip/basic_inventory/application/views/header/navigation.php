<nav class="nav">
    <ul>
        <li><a href="<?=base_url('inventory'); ?>"><i class="fa fa-home fa-2x"></i><br/>Home</a></li>
        <li><a href="<?=base_url('items'); ?>"><i class="fa fa-smile-o fa-2x"></i><br/>Item List</a></li>
        <li><a href="<?=base_url('invoice'); ?>"><i class="fa fa-file-text fa-2x"></i><br/>Invoices</a></li>
        <li><a href="<?=base_url('inventory/damage_items'); ?>"><i class="fa fa-unlink fa-2x"></i><br/>Damages</a></li>
        <li><a href="<?=base_url('suppliers'); ?>"><i class="fa fa-truck fa-2x"></i><br/>Suppliers</a></li>
        <li><a href="<?=base_url('users'); ?>"><i class="fa fa-user fa-2x"></i><br/>Users</a></li>
        <li><a href="<?=base_url('settings'); ?>"><i class="fa fa-cogs fa-2x"></i><br/>Settings</a></li>
        <li><a href="<?=base_url('login/logout'); ?>"><i class="fa fa-sign-out fa-2x"></i><br/>Logout</a></li>
    </ul>
</nav>