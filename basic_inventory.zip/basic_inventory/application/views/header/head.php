<!-- Normalize CSS -->
<link href="<?=base_url();?>/assets/css/normalize.css" rel="stylesheet" media="screen">

<!-- Bootstrap core CSS -->
<link href="<?=base_url();?>/assets/bootstrap-3.2.0/css/bootstrap.css" rel="stylesheet" media="screen">

<!-- Font Awesome -->
<link href="<?=base_url();?>/assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" media="screen">

<!-- DATA TABLES -->
<link href="<?=base_url();?>/assets/datatable/css/dataTables.bootstrap.css" rel="stylesheet" media="screen">

<!-- Custom CSS  -->
<link href="<?=base_url();?>/assets/css/navigation.css" rel="stylesheet" media="screen">
<link href="<?=base_url();?>/assets/css/style.css" rel="stylesheet" media="screen">
<!-- jQuery 2.0.3 -->
<script src="<?=base_url();?>/assets/js/jquery-2.0.3.min.js"></script>
<script src="<?=base_url();?>/assets/js/script.js"></script>

<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->